import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export default function Footer() {
  const currentYear = 2026;

  const serviceLinks = [
    { id: 'footer_service_interior', label: 'Curățare Interioară', href: '/services' },
    { id: 'footer_service_headlight', label: 'Restaurare Faruri', href: '/services' },
    { id: 'footer_service_pricing', label: 'Prețuri', href: '/pricing' },
  ];

  const companyLinks = [
    { id: 'footer_company_about', label: 'Despre Noi', href: '/homepage#about' },
    { id: 'footer_company_gallery', label: 'Galerie', href: '/gallery' },
    { id: 'footer_company_booking', label: 'Rezervare Online', href: '/online-booking' },
  ];

  const contactLinks = [
    { id: 'footer_contact_phone', label: '+373 78 929 508', href: 'tel:+37378929508' },
    { id: 'footer_contact_email', label: 'carcuckoo@gmail.com', href: 'mailto:carcuckoo@gmail.com' },
    { id: 'footer_contact_location', label: 'Toată Moldova', href: '/contact' },
  ];

  return (
    <footer className="bg-gray-800 border-t border-gray-700 py-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-md">
                <Icon name="TruckIcon" size={24} className="text-gray-900" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-gray-100">Cuckoo Car</h3>
                <p className="text-xs text-gray-400">Curățare Auto Mobile</p>
              </div>
            </div>
            <p className="text-sm text-gray-300">
              Servicii profesionale de curățare auto la domiciliu în Chișinău.
            </p>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-sm font-semibold text-gray-100 mb-4">Servicii</h4>
            <ul className="space-y-2">
              {serviceLinks?.map((link) => (
                <li key={link?.id}>
                  <Link
                    href={link?.href}
                    className="text-sm text-gray-300 hover:text-primary transition-colors"
                  >
                    {link?.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-sm font-semibold text-gray-100 mb-4">Companie</h4>
            <ul className="space-y-2">
              {companyLinks?.map((link) => (
                <li key={link?.id}>
                  <Link
                    href={link?.href}
                    className="text-sm text-gray-300 hover:text-primary transition-colors"
                  >
                    {link?.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-semibold text-gray-100 mb-4">Contact</h4>
            <ul className="space-y-2">
              {contactLinks?.map((link) => (
                <li key={link?.id}>
                  <Link
                    href={link?.href}
                    className="text-sm text-gray-300 hover:text-primary transition-colors"
                  >
                    {link?.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Social Media */}
        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="flex flex-col items-center gap-4">
            <h4 className="text-sm font-semibold text-gray-100">Urmărește-ne</h4>
            <div className="flex items-center gap-6">
              <a
                href="https://www.tiktok.com/@cuckoocar"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-300 hover:text-primary transition-colors"
                aria-label="TikTok"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
                </svg>
              </a>
              <a
                href="https://www.instagram.com/cuckcarwash/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-300 hover:text-primary transition-colors"
                aria-label="Instagram"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
              <a
                href="viber://chat?number=%2B37378929508"
                className="text-gray-300 hover:text-primary transition-colors"
                aria-label="Viber"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M11.4 0C9.473.028 5.333.344 3.02 2.467 1.302 4.187.696 6.7.633 9.817.57 12.933.488 18.617 6.55 20.23h.01l-.006 2.732s-.037.98.61 1.179c.777.242 1.233-.5 1.977-1.303.407-.44.972-1.084 1.397-1.58 3.85.323 6.812-.416 7.15-.525.776-.252 5.176-.816 5.892-6.657.74-6.02-.36-9.83-2.34-11.546 0 0-1.086-1.254-4.066-1.635A12.88 12.88 0 0 0 11.4 0z"/>
                </svg>
              </a>
              <a
                href="https://wa.me/37378929508"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-300 hover:text-primary transition-colors"
                aria-label="WhatsApp"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-gray-400">
              © {new Date()?.getFullYear()} Cuckoo Car. Toate drepturile rezervate.
            </p>
            <div className="flex items-center gap-6">
              <Link href="#" className="text-sm text-gray-400 hover:text-primary transition-colors">
                Termeni și Condiții
              </Link>
              <Link href="#" className="text-sm text-gray-400 hover:text-primary transition-colors">
                Politica de Confidențialitate
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}