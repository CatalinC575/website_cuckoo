"use client";

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'nav_home', href: '/homepage', label: 'Acasă' },
    { id: 'nav_services', href: '/services', label: 'Servicii' },
    { id: 'nav_pricing', href: '/pricing', label: 'Prețuri' },
    { id: 'nav_gallery', href: '/gallery', label: 'Galerie' },
    { id: 'nav_contact', href: '/contact', label: 'Contact' },
  ];

  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const adminStatus = localStorage.getItem('adminLoggedIn') === 'true';
      setIsAdmin(adminStatus);
    }
  }, [pathname]);

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-gray-800/95 backdrop-blur-md shadow-lg shadow-black/20' : 'bg-gray-800'
      }`}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link href="/homepage" className="flex items-center gap-3 group">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
              <Icon name="TruckIcon" size={24} className="text-gray-900" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-gray-100 tracking-tight">Cuckoo Car</span>
              <span className="text-xs text-gray-300">Curățare Auto Mobilă</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks?.map((link) => (
              <Link
                key={link?.id}
                href={link?.href}
                className={`text-sm font-medium transition-colors hover:text-primary ${
                  pathname === link?.href ? 'text-primary' : 'text-gray-300'
                }`}
              >
                {link?.label}
              </Link>
            ))}
          </nav>

          {/* CTA Button + Mobile Menu */}
          <div className="flex items-center gap-4">
            <Link
              href="/online-booking"
              className="hidden sm:inline-flex items-center gap-2 px-6 py-3 bg-primary text-black font-semibold rounded-xl hover:bg-primary/90 transition-all hover:shadow-lg"
            >
              <Icon name="CalendarIcon" size={20} />
              <span>Rezervă Acum</span>
            </Link>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 text-gray-300 hover:text-primary transition-colors"
              aria-label="Toggle menu"
            >
              <Icon name={isMobileMenuOpen ? 'XMarkIcon' : 'Bars3Icon'} size={24} />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden py-4 border-t border-gray-700">
            <nav className="flex flex-col gap-2">
              {navLinks?.map((link) => (
                <Link
                  key={link?.id}
                  href={link?.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`px-4 py-3 rounded-lg font-medium transition-colors ${
                    pathname === link?.href
                      ? 'bg-primary/20 text-primary' : 'text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {link?.label}
                </Link>
              ))}
              <Link
                href="/online-booking"
                onClick={() => setIsMobileMenuOpen(false)}
                className="mt-2 flex items-center justify-center gap-2 px-4 py-3 bg-primary text-black font-semibold rounded-lg"
              >
                <Icon name="CalendarIcon" size={20} />
                <span>Rezervă Acum</span>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}