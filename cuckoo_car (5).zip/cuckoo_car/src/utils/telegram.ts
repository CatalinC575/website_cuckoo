interface BookingData {
  fullName: string;
  phone: string;
  email: string;
  city: string;
  vehicleType: string;
  vehicleBrand: string;
  preferredDate: string;
  preferredTime: string;
  service: string;
  notes: string;
  timestamp: string;
}

export async function sendTelegramNotification(booking: BookingData): Promise<boolean> {
  const botToken = process.env.NEXT_PUBLIC_TELEGRAM_BOT_TOKEN;
  const chatId = process.env.NEXT_PUBLIC_TELEGRAM_CHAT_ID;

  if (!botToken || !chatId) {
    console.error('Telegram credentials missing');
    return false;
  }

  const message = `
🚗 *REZERVARE NOUĂ*

👤 *Client:* ${booking.fullName}
📞 *Telefon:* ${booking.phone}
🏙️ *Oraș:* ${booking.city}

🚙 *Vehicul:* ${booking.vehicleBrand}
🔧 *Tip:* ${booking.vehicleType}

📅 *Data:* ${booking.preferredDate}
✨ *Serviciu:* ${booking.service}

📝 *Note:* ${booking.notes || 'N/A'}

⏱️ *Timestamp:* ${new Date(booking.timestamp).toLocaleString('ro-RO')}

📊 *Status Rezervare:* ⚠️ NECONFIRMAT
  `.trim();

  try {
    const response = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text: message,
          parse_mode: 'Markdown',
        }),
      }
    );

    const data = await response.json();
    return data.ok;
  } catch (error) {
    console.error('Failed to send Telegram notification:', error);
    return false;
  }
}
