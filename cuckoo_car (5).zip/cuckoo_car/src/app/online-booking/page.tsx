import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';
import BookingForm from './components/BookingForm';
import WhatHappensNextSection from './components/WhatHappensNextSection';

export const metadata: Metadata = {
  title: 'Rezervare Online - Cuckoo Car',
  description: 'Rezervă curățare chimică interioară auto la domiciliu. Formular simplu, confirmare rapidă, serviciu profesional.',
  keywords: 'rezervare auto, booking online, curățare auto Moldova',
};

export default function OnlineBookingPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen pt-20">
        {/* Page Header */}
        <section className="py-16 bg-gradient-to-br from-gray-800 to-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center animate-fade-up">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-100 mb-4">
              Rezervă Acum
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Completează formularul și te contactăm în cel mai scurt timp pentru confirmare
            </p>
          </div>
        </section>

        {/* Booking Form */}
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <BookingForm />
          </div>
        </section>

        <WhatHappensNextSection />
      </main>
      <Footer />
    </>
  );
}