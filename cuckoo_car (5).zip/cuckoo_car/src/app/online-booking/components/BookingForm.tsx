"use client";

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';
import { sendTelegramNotification } from '@/utils/telegram';

interface FormData {
  fullName: string;
  phone: string;
  city: string;
  vehicleType: string;
  vehicleBrand: string;
  preferredDate: string;
  service: string;
  notes: string;
}

export default function BookingForm() {
  const [isHydrated, setIsHydrated] = useState(false);
  const [formData, setFormData] = useState<FormData>({
    fullName: '',
    phone: '',
    city: '',
    vehicleType: '',
    vehicleBrand: '',
    preferredDate: '',
    service: '',
    notes: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const vehicleTypes = [
    { id: 'type_car', value: 'autoturism', label: 'Autoturism' },
    { id: 'type_minibus', value: 'microbuz', label: 'Microbuz' },
    { id: 'type_truck', value: 'camion', label: 'Camion' },
    { id: 'type_agricultural', value: 'utilaj', label: 'Utilaj Agricol' },
  ];

  const services = [
    { id: 'service_interior', value: 'interior', label: 'Curățare Chimică Interioară' },
    { id: 'service_headlight', value: 'faruri', label: 'Restaurare Faruri' },
    { id: 'service_both', value: 'complet', label: 'Pachet Complet (Interior + Faruri)' },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Save to localStorage (mock database)
    if (isHydrated && typeof window !== 'undefined') {
      const bookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      const newBooking = {
        ...formData,
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        status: 'neconfirmat',
      };
      bookings.push(newBooking);
      localStorage.setItem('bookings', JSON.stringify(bookings));

      // Send Telegram notification
      await sendTelegramNotification(newBooking);
    }

    setIsSubmitting(false);
    setSubmitSuccess(true);
    
    // Scroll to top of page
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // Reset form after 3 seconds
    setTimeout(() => {
      setSubmitSuccess(false);
      setFormData({
        fullName: '',
        phone: '',
        city: '',
        vehicleType: '',
        vehicleBrand: '',
        preferredDate: '',
        service: '',
        notes: '',
      });
    }, 7000);
  };

  if (submitSuccess) {
    return (
      <div className="max-w-2xl mx-auto bg-green-900/30 border-2 border-green-400 rounded-2xl p-8 text-center animate-fade-up">
        <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="CheckCircleIcon" size={32} className="text-white" />
        </div>
        <h3 className="text-2xl font-bold text-gray-100 mb-2">Mulțumim!</h3>
        <p className="text-gray-300 mb-4">
          Rezervarea ta a fost trimisă cu succes. Te vom contacta în curând pentru a confirma detaliile.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-3xl mx-auto space-y-6">
      {/* Personal Information */}
      <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 shadow-md">
        <h3 className="text-xl font-bold text-gray-100 mb-4 flex items-center gap-2">
          <Icon name="UserIcon" size={24} className="text-primary" />
          Informații Personale
        </h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="fullName" className="block text-sm font-semibold text-gray-100 mb-2">
              Nume Complet *
            </label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              value={formData.fullName}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              placeholder="Ion Popescu"
            />
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-semibold text-gray-100 mb-2">
              Telefon *
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              placeholder="+373 XXX XXX XX"
            />
          </div>
        </div>
        <div className="mt-4">
          <label htmlFor="city" className="block text-sm font-semibold text-gray-100 mb-2">
            Oraș *
          </label>
          <input
            type="text"
            id="city"
            name="city"
            value={formData.city}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
            placeholder="Chișinău"
          />
        </div>
      </div>

      {/* Vehicle Information */}
      <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 shadow-md">
        <h3 className="text-xl font-bold text-gray-100 mb-4 flex items-center gap-2">
          <Icon name="TruckIcon" size={24} className="text-primary" />
          Informații Vehicul
        </h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="vehicleType" className="block text-sm font-semibold text-gray-100 mb-2">
              Tip Vehicul *
            </label>
            <select
              id="vehicleType"
              name="vehicleType"
              value={formData.vehicleType}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
            >
              <option value="">Selectează...</option>
              {vehicleTypes.map((type) => (
                <option key={type.id} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label htmlFor="vehicleBrand" className="block text-sm font-semibold text-gray-100 mb-2">
              Marcă și Model *
            </label>
            <input
              type="text"
              id="vehicleBrand"
              name="vehicleBrand"
              value={formData.vehicleBrand}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              placeholder="Toyota Corolla"
            />
          </div>
        </div>
      </div>

      {/* Date & Time */}
      <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 shadow-md">
        <h3 className="text-xl font-bold text-gray-100 mb-4 flex items-center gap-2">
          <Icon name="CalendarIcon" size={24} className="text-primary" />
          Data Dorită
        </h3>
        <div>
          <label htmlFor="preferredDate" className="block text-sm font-semibold text-gray-100 mb-2">
            Data Preferată *
          </label>
          <input
            type="date"
            id="preferredDate"
            name="preferredDate"
            value={formData.preferredDate}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
          />
        </div>
      </div>

      {/* Service Selection */}
      <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 shadow-md">
        <h3 className="text-xl font-bold text-gray-100 mb-4 flex items-center gap-2">
          <Icon name="SparklesIcon" size={24} className="text-primary" />
          Serviciu Dorit
        </h3>
        <div className="space-y-3">
          {services.map((service) => (
            <label
              key={service.id}
              className="flex items-center gap-3 p-4 bg-gray-900 border border-gray-700 rounded-xl cursor-pointer hover:border-primary transition-colors"
            >
              <input
                type="radio"
                name="service"
                value={service.value}
                checked={formData.service === service.value}
                onChange={handleChange}
                required
                className="w-5 h-5 text-primary"
              />
              <span className="font-medium text-gray-100">{service.label}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Additional Notes */}
      <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 shadow-md">
        <label htmlFor="notes" className="block text-sm font-semibold text-gray-100 mb-2">
          Note Adiționale (Opțional)
        </label>
        <textarea
          id="notes"
          name="notes"
          value={formData.notes}
          onChange={handleChange}
          rows={4}
          className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all resize-none"
          placeholder="Menționează orice detalii importante..."
        />
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        disabled={isSubmitting}
        className="w-full py-4 bg-primary text-black font-bold rounded-xl hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-lg"
      >
        {isSubmitting ? (
          <>
            <Icon name="ArrowPathIcon" size={24} className="animate-spin" />
            <span>Se trimite...</span>
          </>
        ) : (
          <>
            <Icon name="PaperAirplaneIcon" size={24} />
            <span>Trimite Rezervarea</span>
          </>
        )}
      </button>

      <p className="text-sm text-center text-gray-400">
        * Câmpuri obligatorii. Te vom contacta în maxim 24 de ore pentru confirmare.
      </p>
    </form>
  );
}