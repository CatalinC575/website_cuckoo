import Icon from '@/components/ui/AppIcon';

export default function WhatHappensNextSection() {
  const steps = [
    {
      id: 'next_confirmation',
      number: '1',
      icon: 'PhoneIcon',
      title: 'Confirmare Telefonică',
      description: 'Te sunăm pentru a confirma data, ora și locația exactă',
      time: 'În maxim 24 ore',
    },
    {
      id: 'next_appointment',
      number: '2',
      icon: 'CalendarIcon',
      title: 'Programare Fixată',
      description: 'Primești SMS de confirmare cu toate detaliile',
      time: 'După confirmare',
    },
    {
      id: 'next_service',
      number: '3',
      icon: 'SparklesIcon',
      title: 'Serviciu Executat',
      description: 'Echipa noastră vine la tine și curăță vehiculul',
      time: 'La data stabilită',
    },
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-gray-800 to-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-up">
          <h2 className="text-3xl font-bold text-gray-100 mb-4">
            Ce Se Întâmplă După Rezervare?
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Procesul simplu în 3 pași până la serviciu
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {steps.map((step, index) => (
            <div
              key={step.id}
              className={`relative animate-fade-up delay-${index * 100}`}
            >
              {/* Connecting Arrow (hidden on mobile) */}
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-16 left-full w-full -translate-x-1/2 z-0">
                  <Icon name="ArrowRightIcon" size={24} className="text-gray-600 mx-auto" />
                </div>
              )}

              <div className="relative bg-gray-800 rounded-2xl p-6 border border-gray-700 shadow-md hover:shadow-xl hover:border-primary/50 transition-all">
                {/* Step Number */}
                <div className="absolute -top-4 -left-4 w-12 h-12 bg-primary rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-gray-900 font-bold text-xl">{step.number}</span>
                </div>

                {/* Icon */}
                <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                  <Icon name={step.icon as any} size={32} className="text-primary" />
                </div>

                {/* Content */}
                <h3 className="text-lg font-bold text-gray-100 mb-2 text-center">{step.title}</h3>
                <p className="text-sm text-gray-300 mb-3 text-center">{step.description}</p>

                {/* Time Badge */}
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-gray-700 rounded-full mx-auto block w-fit">
                  <Icon name="ClockIcon" size={14} className="text-gray-300" />
                  <span className="text-xs font-medium text-gray-300">{step.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact Info */}
        <div className="mt-12 text-center animate-fade-up delay-300">
          <div className="inline-flex items-center gap-2 px-6 py-3 bg-cyan-900/30 border border-cyan-500 text-cyan-500 rounded-xl">
            <Icon name="InformationCircleIcon" size={20} />
            <span className="text-sm font-medium">
              Întrebări? Sună-ne la{' '}
              <a href="tel:+373XXXXXXXX" className="font-bold underline">
                +373 XXX XXX XX
              </a>
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}