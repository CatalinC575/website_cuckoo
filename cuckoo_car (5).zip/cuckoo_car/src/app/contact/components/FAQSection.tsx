"use client";

import { useState } from 'react';
import Icon from '@/components/ui/AppIcon';

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      id: 'faq_coverage',
      question: 'În ce zone oferți servicii?',
      answer: 'Oferim servicii mobile în toată Republica Moldova. Ajungem în orice oraș sau localitate unde este nevoie.',
    },
    {
      id: 'faq_duration',
      question: 'Cât durează curățarea?',
      answer: 'În funcție de tipul vehiculului: autoturisme 3-5 ore, microbuze 4-6 ore, camioane 6-12 ore. Durata exactă depinde de starea interiorului.',
    },
    {
      id: 'faq_payment',
      question: 'Ce metode de plată acceptați?',
      answer: 'Acceptăm plata cash/cu cardul bancar la finalizarea serviciului. Pentru clienți corporate oferim și plată cu factură.',
    },
    {
      id: 'faq_products',
      question: 'Ce produse folosiți?',
      answer: 'Folosim doar produse profesionale, biodegradabile și non-toxice. Toate sunt sigure pentru tine, familia ta și mediu.',
    },
    {
      id: 'faq_info',
      question: 'Sunteți total mobili?',
      answer: 'Suntem echipați cu toate echipamentele și produsele necesare, nu avem nevoie de nimic din partea dvs.',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-800 to-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-up">
          <h2 className="text-3xl font-bold text-gray-100 mb-4">
            Întrebări Frecvente
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Răspunsuri rapide la cele mai comune întrebări
          </p>
        </div>

        <div className="max-w-3xl mx-auto space-y-4">
          {faqs?.map((faq, index) => (
            <div
              key={faq?.id}
              className={`bg-gray-800 border border-gray-700 rounded-2xl shadow-md overflow-hidden transition-all animate-fade-up delay-${index * 100}`}
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-700 transition-colors text-gray-100"
              >
                <h3 className="text-lg font-semibold text-gray-100">{faq?.question}</h3>
                <Icon
                  name="ChevronDownIcon"
                  size={24}
                  className={`text-primary transition-transform ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 pb-6">
                  <p className="text-gray-300 leading-relaxed">{faq?.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}