"use client";

import { useState, useEffect } from 'react';
import Icon from '@/components/ui/AppIcon';

interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  message: string;
}

export default function ContactForm() {
  const [isHydrated, setIsHydrated] = useState(false);
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    phone: '',
    message: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Save to localStorage (mock)
    if (isHydrated && typeof window !== 'undefined') {
      const messages = JSON.parse(localStorage.getItem('contactMessages') || '[]');
      messages.push({
        ...formData,
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
      });
      localStorage.setItem('contactMessages', JSON.stringify(messages));
    }

    setIsSubmitting(false);
    setSubmitSuccess(true);

    setTimeout(() => {
      setSubmitSuccess(false);
      setFormData({ name: '', email: '', phone: '', message: '' });
    }, 3000);
  };

  if (submitSuccess) {
    return (
      <div className="max-w-2xl mx-auto bg-green-900/30 border-2 border-green-400 rounded-2xl p-8 text-center animate-fade-up">
        <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
          <Icon name="CheckCircleIcon" size={32} className="text-white" />
        </div>
        <h3 className="text-2xl font-bold text-gray-100 mb-2">Mesaj Trimis!</h3>
        <p className="text-gray-300">
          Mulțumim! Te vom contacta în cel mai scurt timp.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
      <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 sm:p-8 shadow-md">
        <div className="grid sm:grid-cols-2 gap-6 mb-6">
          <div>
            <label htmlFor="name" className="block text-sm font-semibold text-gray-100 mb-2">
              Nume Complet *
            </label>
            <input
              type="text"
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              placeholder="Ion Popescu"
            />
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-semibold text-gray-100 mb-2">
              Telefon *
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              required
              className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              placeholder="+373 XXX XXX XX"
            />
          </div>
        </div>

        <div className="mb-6">
          <label htmlFor="email" className="block text-sm font-semibold text-gray-100 mb-2">
            Email *
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            required
            className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
            placeholder="ion@example.com"
          />
        </div>

        <div className="mb-6">
          <label htmlFor="message" className="block text-sm font-semibold text-gray-100 mb-2">
            Mesaj *
          </label>
          <textarea
            id="message"
            name="message"
            value={formData.message}
            onChange={handleChange}
            required
            rows={6}
            className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all resize-none"
            placeholder="Scrie mesajul tău aici..."
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-4 bg-primary text-black font-bold rounded-xl hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {isSubmitting ? (
            <>
              <Icon name="ArrowPathIcon" size={24} className="animate-spin" />
              <span>Se trimite...</span>
            </>
          ) : (
            <>
              <Icon name="PaperAirplaneIcon" size={24} />
              <span>Trimite Mesajul</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
}