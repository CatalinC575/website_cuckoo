import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';
import ContactInfoSection from './components/ContactInfoSection';
import FAQSection from './components/FAQSection';

export const metadata: Metadata = {
  title: 'Contact - Cuckoo Car',
  description: 'Contactează Cuckoo Car pentru curățare auto mobilă în Moldova. Telefon, email, formular de contact. Serviciu în toată țara.',
  keywords: 'contact auto detailing, rezervare curățare auto, Moldova',
};

export default function ContactPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen pt-20">
        {/* Page Header */}
        <section className="py-16 bg-gradient-to-br from-gray-800 to-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center animate-fade-up">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-100 mb-4">
              Contactează-ne
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Suntem aici pentru tine. Alege cum vrei să ne contactezi.
            </p>
          </div>
        </section>

        <ContactInfoSection />

        <FAQSection />
      </main>
      <Footer />
    </>
  );
}