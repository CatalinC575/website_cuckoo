"use client";

import { useState, useEffect } from 'react';
import AppImage from '@/components/ui/AppImage';

export default function GalleryGrid() {
  const [isHydrated, setIsHydrated] = useState(false);
  const [activeFilter, setActiveFilter] = useState('all');

  useEffect(() => {
    setIsHydrated(true);
  }, []);

  const categories = [
  { id: 'filter_all', value: 'all', label: 'Toate' },
  { id: 'filter_seats', value: 'seats', label: 'Scaune' },
  { id: 'filter_carpets', value: 'carpets', label: 'Covoare' },
  { id: 'filter_leather', value: 'leather', label: 'Piele' },
  { id: 'filter_dashboard', value: 'dashboard', label: 'Bord' },
  { id: 'filter_headlights', value: 'headlights', label: 'Faruri' }];


  const galleryItems = [
  {
    id: 'gallery_seats_1',
    category: 'seats',
    beforeImage: "https://lh3.googleusercontent.com/pw/AP1GczOEFi8v_3C73ghEIn6EhDcDPXoO8mSGRNmYoE6cz9sZITO_k5PPU_ZUHLEHIo6D85rrKea8o9HLvWKwrr4IZ-9IE33pm3SFC6pIPC6vDbDjiBank9d2KLDVfsn-JJ1FZpCV0dpaH7dIvn865E5y7wZX=w670-h1437-s-no-gm?authuser=0",
    beforeAlt: 'Dirty stained fabric car seat with visible dirt marks and food stains before chemical cleaning treatment',
    afterImage: "https://lh3.googleusercontent.com/pw/AP1GczM_g4PgJbgOLpRex2fD76x7RUnco1876uuDksG7P-G9HMkz8D4kmSTG-oiOC_2xGk7VlfSKp6NjMkWdIy7J-frVp1FKr-8WhXTVhl2zmPg5tiIWXSj3jRJC_ozpHpZnxC7734VA5en6pvjhX8Yk4A8k=w672-h1435-s-no-gm?authuser=0",
    afterAlt: 'Clean restored fabric car seat after professional chemical cleaning showing fresh appearance',
    title: 'Scaune Textile'
  },
  {
    id: 'gallery_leather_1',
    category: 'leather',
    beforeImage: "https://lh3.googleusercontent.com/pw/AP1GczM-PnlmMVKCU8eaI_QTPDEMzUcta-dvkUueo30Vxih2hAB8Yv-bgKX1jEtspSwGPPjPaOUuUNPx9XZcwcVzcHix29mwnK2z05aTQh78Xd1OOEC7mRK8Rfbd4rp1Kc5Tjy0vjHM7YDXn1kMLwFUOuopE=w704-h1433-s-no-gm?authuser=0",
    beforeAlt: 'Worn leather car seat with cracks and dirt accumulation before restoration treatment',
    afterImage: "https://lh3.googleusercontent.com/pw/AP1GczNa5FXvJtg-2aQQHbdCt8vCt_LnP-rgwqam4NDIzq27f37c-sRLFFD9hcc7NCgIwzi876qeSaO78WszDNTpE3WmHW44mYFeRch4ipijklQI9y19xn9piAgitLKI4mlqhExuNBzbZawcxAktyIEQTpX4=w720-h1433-s-no-gm?authuser=0",
    afterAlt: 'Conditioned leather car seat after professional cleaning and treatment showing restored shine',
    title: 'Piele Restaurată'
  },
  {
    id: 'gallery_carpets_1',
    category: 'carpets',
    beforeImage: "https://img.rocket.new/generatedImages/rocket_gen_img_13e40b549-1769806060961.png",
    beforeAlt: 'Muddy car floor carpet with embedded dirt and stains before deep chemical cleaning',
    afterImage: "https://img.rocket.new/generatedImages/rocket_gen_img_1c9d4a8d9-1766606463244.png",
    afterAlt: 'Fresh clean car floor carpet after professional extraction cleaning showing restored fibers',
    title: 'Covoare Curate'
  },
  {
    id: 'gallery_dashboard_1',
    category: 'dashboard',
    beforeImage: "https://lh3.googleusercontent.com/pw/AP1GczOfchBZgGkzsOG8h56ngMNKJfOBXF_Z5fLkSQe4qfhwnwBAA0YPDAKc9dL0s_73BwjM8Ni-w4TJK-7V9VoeA_aHZfQ9shotx-cPMhVnjrLiqQIs1pNSviSrV9aTEpYy9oCCWSLb-zYXhqhwSPc6xRng=w718-h1433-s-no-gm?authuser=0",
    beforeAlt: 'Dusty car dashboard with fingerprints and grime on plastic surfaces before detailing',
    afterImage: "https://lh3.googleusercontent.com/pw/AP1GczPZiYCGYX4dIe-W25D7IYffaMqHzIMoYEb1oYwdxgQuiFUBHo7NyhDi-XkVD0IEiA8BUynGZFKUICLCQKoZHPqMPMBN0piEILt2ub1l_jP1fhjgEF313BIhUCi3k2DFAFlANjFEWTm6ffI5ZX7_JBRG=w717-h1428-s-no-gm?authuser=0",
    afterAlt: 'Polished car dashboard after professional cleaning showing glossy finish and restored plastic',
    title: 'Bord Curățat'
  },
  {
    id: 'gallery_headlights_1',
    category: 'headlights',
    beforeImage: "https://img.rocket.new/generatedImages/rocket_gen_img_1e73f1b3e-1764734283334.png",
    beforeAlt: 'Foggy yellowed car headlight with oxidation before polishing restoration',
    afterImage: "https://img.rocket.new/generatedImages/rocket_gen_img_1dd615c24-1764734286619.png",
    afterAlt: 'Crystal clear car headlight after professional restoration showing perfect transparency',
    title: 'Faruri Restaurate'
  },
  {
    id: 'gallery_seats_2',
    category: 'seats',
    beforeImage: "https://img.rocket.new/generatedImages/rocket_gen_img_13191ef65-1769806059506.png",
    beforeAlt: 'Heavily soiled car seat with multiple stains and dirt before intensive cleaning',
    afterImage: "https://img.rocket.new/generatedImages/rocket_gen_img_1a403b5f7-1768165846343.png",
    afterAlt: 'Spotless car seat after deep cleaning treatment showing like-new condition',
    title: 'Scaune Revitalizate'
  }];


  const filteredItems = activeFilter === 'all' ?
  galleryItems :
  galleryItems?.filter((item) => item?.category === activeFilter);

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Filter Buttons */}
        <div className="flex flex-wrap justify-center gap-3 mb-12 animate-fade-up">
          {categories?.map((category) =>
            <button
            key={category?.id}
            onClick={() => setActiveFilter(category?.value)}
            className={`px-6 py-3 rounded-xl font-semibold transition-all ${
              activeFilter === category?.value
                ? 'bg-primary text-black shadow-lg'
                : 'bg-gray-800 text-gray-100 border border-gray-700 hover:border-primary'
            }`}>

              {category?.label}
            </button>
          )}
        </div>

        {/* Gallery Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems?.map((item, index) =>
          <div
            key={item?.id}
            className={`group animate-fade-up delay-${index * 100}`}>

              <div className="bg-gray-800 border border-gray-700 rounded-2xl shadow-md overflow-hidden hover:shadow-xl hover:border-primary/50 transition-all duration-300">
                {/* Before/After Images */}
                <div className="relative aspect-[4/3]">
                  <div className="absolute inset-0 grid grid-cols-2">
                    {/* Before */}
                    <div className="relative overflow-hidden">
                      <AppImage
                      src={item?.beforeImage}
                      alt={item?.beforeAlt}
                      className="w-full h-full object-cover" />

                      <div className="absolute top-2 left-2 px-3 py-1 bg-gray-900/90 text-gray-100 text-xs font-semibold rounded-lg">
                        Înainte
                      </div>
                    </div>
                    {/* After */}
                    <div className="relative overflow-hidden">
                      <AppImage
                      src={item?.afterImage}
                      alt={item?.afterAlt}
                      className="w-full h-full object-cover" />

                      <div className="absolute top-2 right-2 px-3 py-1 bg-primary/90 text-gray-900 text-xs font-semibold rounded-lg">
                        După
                      </div>
                    </div>
                  </div>
                </div>

                {/* Title */}
                <div className="p-4">
                  <h3 className="font-bold text-gray-100 text-center">{item?.title}</h3>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}