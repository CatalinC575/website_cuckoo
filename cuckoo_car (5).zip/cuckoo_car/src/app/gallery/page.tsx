import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';
import GalleryGrid from './components/GalleryGrid';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export const metadata: Metadata = {
  title: 'Galerie - Cuckoo Car',
  description: 'Vezi rezultatele noastre - imagini înainte și după curățare chimică interioară auto. Lucrări reale, rezultate profesionale.',
  keywords: 'galerie auto detailing, înainte și după, curățare auto Moldova',
};

export default function GalleryPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen pt-20">
        {/* Page Header */}
        <section className="py-16 bg-gradient-to-br from-gray-800 to-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center animate-fade-up">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-100 mb-4">
              Galeria Noastră
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Rezultate reale, înainte și după. Transformări complete ale interioarelor auto.
            </p>
          </div>
        </section>

        <GalleryGrid />

        {/* CTA Section */}
        <section className="py-16 bg-gray-800">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-gray-100 mb-4">
              Vrei Rezultate Ca Acestea?
            </h2>
            <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
              Rezervă acum și transformăm interiorul mașinii tale
            </p>
            <Link
              href="/online-booking"
              className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-gray-900 font-bold rounded-xl hover:bg-primary/90 transition-all hover:shadow-lg"
            >
              <Icon name="CalendarIcon" size={24} />
              <span>Rezervă Acum</span>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}