import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';
import InteriorCleaningSection from './components/InteriorCleaningSection';
import VehicleTypesSection from './components/VehicleTypesSection';
import HeadlightRestorationSection from './components/HeadlightRestorationSection';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export const metadata: Metadata = {
  title: 'Servicii - Cuckoo Car',
  description: 'Curățare chimică interioară completă pentru autoturisme, microbuze, camioane și utilaje agricole. Restaurare faruri profesională.',
  keywords: 'curățare interioară, restaurare faruri, servicii auto, Moldova',
};

export default function ServicesPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen pt-20">
        {/* Page Header */}
        <section className="py-16 bg-gradient-to-br from-gray-800 to-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center animate-fade-up">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-100 mb-4">
              Serviciile Noastre
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Curățare profesională și restaurare pentru toate tipurile de vehicule
            </p>
          </div>
        </section>

        <InteriorCleaningSection />
        <VehicleTypesSection />
        <HeadlightRestorationSection />

        {/* CTA Section */}
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-gray-100 mb-4">
              Pregătit să Rezervi?
            </h2>
            <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
              Completează formularul de rezervare și te contactăm pentru confirmare
            </p>
            <Link
              href="/online-booking"
              className="inline-flex items-center gap-2 px-8 py-4 bg-primary text-gray-900 font-bold rounded-xl hover:bg-primary/90 transition-all hover:shadow-lg"
            >
              <Icon name="CalendarIcon" size={24} />
              <span>Rezervă Acum</span>
            </Link>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}