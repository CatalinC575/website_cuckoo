import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

export default function InteriorCleaningSection() {
  const cleaningSteps = [
  {
    id: 'cleaning_brush',
    icon: 'SparklesIcon',
    title: 'Curățare Profundă cu Perii',
    description: 'Folosim perii și soluții speciale pentru a ajunge în cele mai ascunse colțuri'
  },
  {
    id: 'cleaning_stains',
    icon: 'BeakerIcon',
    title: 'Îndepărtarea Petelor',
    description: 'Tratăm petele de pe scaunele textile și covoare cu soluții profesionale'
  },
  {
    id: 'cleaning_leather',
    icon: 'ShieldCheckIcon',
    title: 'Îngrijirea Pielii',
    description: 'Curățăm și condiționăm pielea pentru a păstra aspectul și flexibilitatea'
  },
  {
    id: 'cleaning_plastic',
    icon: 'WrenchIcon',
    title: 'Curățarea Plasticului',
    description: 'Bordul și toate suprafețele de plastic sunt curățate în profunzime'
  },
  {
    id: 'cleaning_odor',
    icon: 'CloudIcon',
    title: 'Eliminarea Mirosurilor',
    description: 'Folosim generator de ozon pentru neutralizarea completă a mirosurilor'
  },
  {
    id: 'cleaning_vacuum',
    icon: 'ArrowPathIcon',
    title: 'Aspirare și Aer Comprimat',
    description: 'Aspirare industrială și curățare cu aer comprimat în zonele dificile'
  }];


  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image Side */}
          <div className="animate-fade-up">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <AppImage
                src="https://img.rocket.new/generatedImages/rocket_gen_img_12f0cfb6c-1764734283088.png"
                alt="Professional car interior detailing showing deep cleaning of leather seats with brushes and chemical products"
                className="w-full h-[500px] object-cover" />

              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6">
                <div className="glass-effect rounded-2xl p-4">
                  <p className="text-white font-semibold text-lg">Curățare Chimică Completă</p>
                  <p className="text-white/80 text-sm">Rezultate profesionale garantate</p>
                </div>
              </div>
            </div>
          </div>

          {/* Content Side */}
          <div className="animate-fade-up delay-200">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-100 mb-6">
              Ce Include Curățarea Chimică Interioară?
            </h2>
            <p className="text-lg text-gray-300 mb-8">
              Un proces complet și detaliat care transformă interiorul mașinii tale
            </p>

            <div className="space-y-4">
              {cleaningSteps.map((step) =>
              <div
                key={step.id}
                className="flex gap-4 p-4 bg-gray-800 rounded-xl border border-gray-700 hover:bg-gray-700 transition-colors">

                  <div className="flex-shrink-0 w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                    <Icon name={step.icon as any} size={24} className="text-gray-900" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-100 mb-1">{step.title}</h3>
                    <p className="text-sm text-gray-300">{step.description}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>);

}