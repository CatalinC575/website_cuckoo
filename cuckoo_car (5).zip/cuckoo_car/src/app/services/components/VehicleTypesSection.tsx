import Icon from '@/components/ui/AppIcon';

export default function VehicleTypesSection() {
  const vehicleTypes = [
    {
      id: 'vehicle_cars',
      icon: 'TruckIcon',
      title: 'Autoturisme',
      description: 'Mașini personale de toate mărimile',
      features: ['Sedan', 'Hatchback', 'SUV', 'Crossover'],
      time: '3-5 ore',
    },
    {
      id: 'vehicle_minibus',
      icon: 'TruckIcon',
      title: 'Microbuze',
      description: 'Vehicule comerciale și transport pasageri',
      features: ['2-6 locuri', 'Transport școlar', 'Taxi colectiv'],
      time: '4-6 ore',
    },
    {
      id: 'vehicle_trucks',
      icon: 'TruckIcon',
      title: 'Camioane',
      description: 'Cabine pentru șoferi profesioniști',
      features: ['Cabine dormitor', 'Camionete', 'Utilitare'],
      time: '6-12 ore',
    },
    {
      id: 'vehicle_agricultural',
      icon: 'WrenchScrewdriverIcon',
      title: 'Utilaje Agricole',
      description: 'Tractoare și mașini specializate',
      features: ['Tractoare', 'Combine', 'Utilaje grele'],
      time: 'La cerere',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-800 to-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-up">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-100 mb-4">
            Tipuri de Vehicule
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Oferim servicii specializate pentru orice tip de vehicul
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {vehicleTypes.map((vehicle, index) => (
            <div
              key={vehicle.id}
              className={`bg-gray-800 border border-gray-700 rounded-2xl p-6 shadow-md hover:shadow-xl hover:border-primary/50 transition-all duration-300 animate-fade-up delay-${index * 100}`}
            >
              <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-4">
                <Icon name={vehicle.icon as any} size={32} className="text-gray-900" />
              </div>

              <h3 className="text-xl font-bold text-gray-100 mb-2">{vehicle.title}</h3>
              <p className="text-sm text-gray-300 mb-4">{vehicle.description}</p>

              <div className="space-y-2 mb-4">
                {vehicle.features.map((feature, idx) => (
                  <div key={`${vehicle.id}_feature_${idx}`} className="flex items-center gap-2 text-sm text-gray-300">
                    <Icon name="CheckCircleIcon" size={16} className="text-primary flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-gray-700">
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  <Icon name="ClockIcon" size={16} />
                  <span>Durată: {vehicle.time}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}