import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

export default function HeadlightRestorationSection() {
  const benefits = [
  {
    id: 'headlight_visibility',
    icon: 'SunIcon',
    title: 'Vizibilitate Îmbunătățită',
    description: 'Lumină mai clară și mai puternică pe timp de noapte'
  },
  {
    id: 'headlight_safety',
    icon: 'ShieldCheckIcon',
    title: 'Siguranță Sporită',
    description: 'Reduci riscul de accident prin iluminare optimă'
  },
  {
    id: 'headlight_appearance',
    icon: 'SparklesIcon',
    title: 'Aspect Îmbunătățit',
    description: 'Mașina arată mai nouă și mai îngrijită'
  }];


  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content Side */}
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-900/30 border border-yellow-400 text-yellow-400 rounded-full text-sm font-medium mb-6">
              <Icon name="LightBulbIcon" size={18} />
              <span>Serviciu Adițional</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-bold text-gray-100 mb-6">
              Restaurare și Lustruire Faruri
            </h2>
            <p className="text-lg text-gray-300 mb-8">
              Farurile galbene sau mate reduc vizibilitatea cu până la 50%. 
              Le redăm claritatea originală prin polizare profesională.
            </p>

            <div className="space-y-4 mb-8">
              {benefits.map((benefit) =>
              <div key={benefit.id} className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-yellow-900/30 border border-yellow-400 rounded-xl flex items-center justify-center">
                    <Icon name={benefit.icon as any} size={24} className="text-yellow-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-100 mb-1">{benefit.title}</h3>
                    <p className="text-sm text-gray-300">{benefit.description}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center gap-4">
              <Link
                href="/pricing"
                className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-gray-900 font-semibold rounded-xl hover:bg-primary/90 transition-all">

                <span>Vezi Prețuri</span>
                <Icon name="ArrowRightIcon" size={20} />
              </Link>
              <p className="text-sm text-gray-300">
                <span className="font-semibold text-gray-100">1000 MDL</span> / set
              </p>
            </div>
          </div>

          {/* Before/After Comparison */}
          <div className="animate-fade-up delay-200">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-semibold text-gray-100 text-center">Înainte</p>
                <div className="relative rounded-2xl overflow-hidden shadow-lg">
                  <AppImage
                    src="https://lh3.googleusercontent.com/pw/AP1GczPW-7RPAfBWUz3QGpHAQ6i-kc3innygFQZw0GjMevhdNHXJQmvncSBhAvMkSg7SlGPu_bZa8YD835Zy05ySLW752J--keiefBbEoSy2_kVMbeUMZv0-o6edj0pSrLZkto2sndCq2u7L5xMsxZqd-Z2U=w800-h800-s-no-gm?authuser=0"
                    alt="Foggy oxidized car headlight before restoration showing yellow discoloration and reduced clarity"
                    className="w-full h-64 object-cover" />

                  <div className="absolute top-3 right-3 px-3 py-1 bg-red-500 text-white text-xs font-semibold rounded-full">
                    Mat
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-semibold text-gray-100 text-center">După</p>
                <div className="relative rounded-2xl overflow-hidden shadow-lg">
                  <AppImage
                    src="https://lh3.googleusercontent.com/pw/AP1GczP0-1rxhEsvta7XGhJIgr3Kx67kFGjZ5IPGAikyd48fGM154XOrzRKDwG2isoYCGcC6qNqH-U7_7xrx3RWMH0i-EJsCWGPdtppVaNYwZ7o_S1EghjlIUGuiilsad8EwAgk8mmD-nU_4jr-S10ft5JBT=w1024-h1024-s-no-gm?authuser=0"
                    alt="Crystal clear restored car headlight after professional polishing showing perfect transparency and brightness"
                    className="w-full h-64 object-cover" />

                  <div className="absolute top-3 right-3 px-3 py-1 bg-green-500 text-white text-xs font-semibold rounded-full">
                    Clar
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 p-4 bg-gray-900 rounded-xl border border-amber-500/30">
              <div className="flex items-start gap-3">
                <Icon name="InformationCircleIcon" size={24} className="text-yellow-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-gray-100 mb-1">Durabilitate Garantată</p>
                  <p className="text-sm text-gray-300">
                    Aplicăm strat protector ceramic care menține claritatea până la 3 ani
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>);

}