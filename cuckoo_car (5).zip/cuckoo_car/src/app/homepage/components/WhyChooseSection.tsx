import Icon from '@/components/ui/AppIcon';

export default function WhyChooseSection() {
  const benefits = [
    {
      id: 'benefit_mobile',
      icon: 'TruckIcon',
      title: 'Venim la Tine',
      description: 'Nu mai pierzi timp deplasându-te. Echipa noastră vine direct la locația ta cu tot echipamentul necesar.',
    },
    {
      id: 'benefit_professional',
      icon: 'WrenchScrewdriverIcon',
      title: 'Echipament Profesional',
      description: 'Folosim aspiratoare industriale, aparate cu abur, și unelte specializate pentru curățare profundă.',
    },
    {
      id: 'benefit_safe',
      icon: 'ShieldCheckIcon',
      title: 'Chimicale Sigure',
      description: 'Produse biodegradabile, non-toxice, sigure pentru tine, familia ta și mediu. Fără mirosuri neplăcute.',
    },
  ];

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-up">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-100 mb-4">
            De Ce Să Alegi Serviciul Nostru Mobil?
          </h2>
          <p className="text-lg text-gray-300 font-medium max-w-2xl mx-auto">
            Economisești timp și primești rezultate profesionale fără să părăsești casa sau biroul
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div
              key={benefit.id}
              className={`group p-8 bg-gray-800 rounded-2xl hover:bg-gray-700 border border-gray-700 hover:border-primary/50 hover:shadow-xl transition-all duration-300 animate-fade-up delay-${index * 100}`}
            >
              <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                <Icon
                  name={benefit.icon as any}
                  size={32}
                  className="text-gray-900"
                />
              </div>
              <h3 className="text-xl font-bold text-gray-100 mb-3">{benefit.title}</h3>
              <p className="text-gray-300 leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}