import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';
import AppImage from '@/components/ui/AppImage';

export default function HeroSection() {
  const floatingServices = [
  {
    id: 'hero_float_interior',
    icon: 'SparklesIcon',
    title: 'Curățare Chimică',
    description: 'Interioară completă'
  },
  {
    id: 'hero_float_mobile',
    icon: 'TruckIcon',
    title: 'Serviciu Mobil',
    description: 'Venim la tine'
  },
  {
    id: 'hero_float_professional',
    icon: 'ShieldCheckIcon',
    title: 'Profesional',
    description: 'Echipament de calitate'
  }];


  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 pb-16 overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 -z-10" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="animate-fade-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 text-gray-900 rounded-full text-sm font-medium mb-6 bg-[rgba(18,248,248,1)]">
              <Icon name="MapPinIcon" size={18} />
              <span>Serviciu în Toată Moldova</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-100 leading-tight mb-6">
              Curățare Chimică Interioară Auto la{' '}
              <span className="text-primary">Domiciliu</span>
            </h1>

            <p className="text-lg text-gray-300 font-medium mb-8 max-w-xl">
              Venim direct la tine cu echipament profesional și chimicale sigure. 
              Transformăm interiorul mașinii tale fără să te deplasezi.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Link
                href="/online-booking"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary text-black font-bold rounded-xl hover:bg-primary/90 transition-all hover:shadow-lg text-lg">

                <Icon name="CalendarIcon" size={24} />
                <span>Rezervă Online</span>
              </Link>

              <Link
                href="/services"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gray-800 text-gray-100 font-semibold rounded-xl border-2 border-gray-700 hover:border-primary hover:text-primary transition-all">

                <span>Vezi Serviciile</span>
                <Icon name="ArrowRightIcon" size={20} />
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="flex items-center gap-8 mt-10 pt-8 border-t border-gray-700">
              <div>
                <p className="text-2xl font-bold text-gray-100">5+</p>
                <p className="text-sm text-gray-300 font-medium">Ani Experiență</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-100">1000+</p>
                <p className="text-sm text-gray-300 font-medium">Mașini Curățate</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-100">100%</p>
                <p className="text-sm text-gray-300 font-medium">Satisfacție</p>
              </div>
            </div>
          </div>

          {/* Right Visual - Floating Cards */}
          <div className="relative animate-fade-up delay-200">
            <div className="relative aspect-square max-w-lg mx-auto">
              {/* Main Image */}
              <div className="absolute inset-0 rounded-3xl overflow-hidden shadow-2xl">
                <AppImage
                  src="https://i.pinimg.com/736x/9c/53/12/9c5312e44da26e46789a8f5d35510f79.jpg"
                  alt="Clean car interior with leather seats, detailed dashboard, and pristine carpet showing professional chemical cleaning results"
                  className="w-full h-full object-cover" />

                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              </div>

              {/* Floating Service Cards */}
              {floatingServices.map((service, index) =>
              <div
                key={service.id}
                className={`absolute glass-effect border border-gray-700 rounded-2xl p-4 shadow-lg animate-fade-up delay-${300 + index * 100}`}
                style={{
                  top: `${20 + index * 25}%`,
                  right: index % 2 === 0 ? '-10%' : 'auto',
                  left: index % 2 !== 0 ? '-10%' : 'auto'
                }}>

                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-md">
                      <Icon name={service.icon as any} size={24} className="text-gray-900" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-100 text-sm">{service.title}</p>
                      <p className="text-xs text-gray-300">{service.description}</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>);

}