import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export default function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-800 to-gray-900 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 2px 2px, white 1px, transparent 0)',
          backgroundSize: '40px 40px',
        }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center animate-fade-up">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-100 mb-4">
            Gata să Transformi Interiorul Mașinii Tale?
          </h2>
          <p className="text-lg text-gray-300 font-medium max-w-2xl mx-auto mb-8">
            Rezervă acum și bucură-te de un interior curat și proaspăt fără să te deplasezi
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Link
              href="/online-booking"
              className="inline-flex items-center gap-2 px-10 py-5 bg-primary text-black font-bold rounded-xl hover:bg-primary/90 transition-all hover:shadow-2xl text-lg group"
            >
              <Icon name="CalendarIcon" size={24} />
              <span>Începe Rezervarea</span>
              <Icon name="ArrowRightIcon" size={20} className="group-hover:translate-x-1 transition-transform" />
            </Link>

            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-10 py-5 bg-transparent text-gray-100 font-semibold rounded-xl border-2 border-gray-700 hover:border-primary hover:text-primary transition-all"
            >
              <Icon name="PhoneIcon" size={24} />
              <span>Sună-ne Acum</span>
            </Link>
          </div>

          {/* Quick Contact Info */}
          <div className="mt-12 pt-8 border-t border-gray-700 flex flex-col sm:flex-row items-center justify-center gap-6 text-gray-300">
            <div className="flex items-center gap-2">
              <Icon name="ClockIcon" size={20} />
              <span className="text-sm font-medium">Luni - Duminică: 8:00 - 20:00</span>
            </div>
            <div className="hidden sm:block w-px h-6 bg-gray-700" />
            <div className="flex items-center gap-2">
              <Icon name="MapPinIcon" size={20} />
              <span className="text-sm font-medium">Serviciu în Toată Moldova</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}