import Icon from '@/components/ui/AppIcon';

export default function HowItWorksSection() {
  const steps = [
    {
      id: 'step_book',
      number: '1',
      icon: 'CalendarIcon',
      title: 'Rezervi Online',
      description: 'Completezi formularul simplu cu data, ora și locația dorită',
    },
    {
      id: 'step_confirm',
      number: '2',
      icon: 'PhoneIcon',
      title: 'Te Confirmăm',
      description: 'Te sunăm pentru confirmare și detalii finale',
    },
    {
      id: 'step_arrive',
      number: '3',
      icon: 'TruckIcon',
      title: 'Venim la Tine',
      description: 'Echipa noastră ajunge la timp cu tot echipamentul',
    },
    {
      id: 'step_enjoy',
      number: '4',
      icon: 'SparklesIcon',
      title: 'Te Bucuri',
      description: 'Mașina ta arată ca nouă, fără efort din partea ta',
    },
  ];

  return (
    <section className="py-20 bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-up">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-100 mb-4">
            Cum Funcționează?
          </h2>
          <p className="text-lg text-gray-300 font-medium max-w-2xl mx-auto">
            Proces simplu în 4 pași - de la rezervare până la rezultatul final
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div
              key={step.id}
              className={`relative animate-fade-up delay-${index * 100}`}
            >
              {/* Connecting Line (hidden on mobile, visible on lg+) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-12 left-full w-full h-0.5 bg-gradient-to-r from-primary to-primary/20 -translate-x-1/2" />
              )}

              <div className="relative bg-gray-900 rounded-2xl p-6 border border-gray-700 hover:bg-gray-700 hover:border-primary/50 hover:shadow-lg transition-all duration-300">
                {/* Step Number Badge */}
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-primary rounded-full flex items-center justify-center shadow-lg">
                  <span className="text-gray-900 font-bold text-xl">{step.number}</span>
                </div>

                {/* Icon */}
                <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center mb-4">
                  <Icon name={step.icon as any} size={32} className="text-gray-900 border-[rgba(166,48,48,1)]" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-gray-100 mb-3">{step.title}</h3>
                <p className="text-gray-300 leading-relaxed">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}