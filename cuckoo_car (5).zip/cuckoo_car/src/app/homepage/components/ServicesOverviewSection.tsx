import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export default function ServicesOverviewSection() {
  const services = [
    {
      id: 'service_cars',
      icon: 'TruckIcon',
      title: 'Autoturisme',
      description: 'Curățare completă pentru mașini personale',
      price: 'de la 2500 MDL',
      color: 'bg-green-500',
    },
    {
      id: 'service_minibus',
      icon: 'TruckIcon',
      title: 'Microbuze',
      description: 'Spații mai mari, aceeași atenție la detalii',
      price: 'de la 2500 MDL',
      color: 'bg-blue-500',
    },
    {
      id: 'service_trucks',
      icon: 'TruckIcon',
      title: 'Camioane',
      description: 'Cabine curate pentru șoferi profesioniști',
      price: 'de la 5000 MDL',
      color: 'bg-cyan-500',
    },
    {
      id: 'service_headlight',
      icon: 'LightBulbIcon',
      title: 'Restaurare Faruri',
      description: 'Redă claritatea și siguranța farurilor',
      price: 'de la 1000 MDL',
      color: 'bg-amber-500',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-800 to-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 animate-fade-up">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-100 mb-4">
            Serviciile Noastre
          </h2>
          <p className="text-lg text-gray-300 font-medium max-w-2xl mx-auto">
            De la autoturisme la utilaje agricole - avem soluția perfectă pentru fiecare vehicul
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {services.map((service, index) => (
            <div
              key={service.id}
              className={`group relative bg-gray-800 rounded-2xl p-6 shadow-md hover:shadow-xl border border-gray-700 hover:border-primary/50 transition-all duration-300 animate-fade-up delay-${index * 100}`}
            >
              <div className={`w-14 h-14 ${service.color} rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <Icon name={service.icon as any} size={28} className="text-white" />
              </div>
              <h3 className="text-xl font-bold text-gray-100 mb-2">{service.title}</h3>
              <p className="text-sm text-gray-300 mb-4">{service.description}</p>
              <p className="text-lg font-bold text-primary">{service.price}</p>
            </div>
          ))}
        </div>

        <div className="text-center animate-fade-up delay-400">
          <Link
            href="/services"
            className="inline-flex items-center gap-2 px-8 py-4 bg-gray-800 text-gray-100 font-semibold rounded-xl border-2 border-gray-700 hover:border-primary hover:text-primary transition-all hover:shadow-lg"
          >
            <span>Vezi Toate Serviciile</span>
            <Icon name="ArrowRightIcon" size={20} />
          </Link>
        </div>
      </div>
    </section>
  );
}