import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';
import HeroSection from './components/HeroSection';
import WhyChooseSection from './components/WhyChooseSection';
import ServicesOverviewSection from './components/ServicesOverviewSection';
import HowItWorksSection from './components/HowItWorksSection';
import CTASection from './components/CTASection';

export const metadata: Metadata = {
  title: 'Cuckoo Car - Curățare Auto Mobilă în Moldova',
  description: 'Serviciu profesional de curățare chimică interioară auto la domiciliu. Venim la tine cu echipament profesional în toată Moldova.',
  keywords: 'curățare auto, curățare interioară, serviciu mobil, Moldova, chimică auto',
};

export default function Homepage() {
  return (
    <>
      <Header />
      <main className="min-h-screen bg-gray-900">
        <HeroSection />
        <WhyChooseSection />
        <ServicesOverviewSection />
        <HowItWorksSection />
        <CTASection />
      </main>
      <Footer />
    </>
  );
}