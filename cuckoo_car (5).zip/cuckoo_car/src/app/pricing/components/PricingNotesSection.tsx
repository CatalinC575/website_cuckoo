import Icon from '@/components/ui/AppIcon';

export default function PricingNotesSection() {
  const notes = [
    {
      id: 'note_condition',
      icon: 'InformationCircleIcon',
      title: 'Prețul Final Depinde de Stare',
      description: 'Prețurile afișate sunt aproximative. Costul final se stabilește după evaluarea stării vehiculului.',
      color: 'bg-cyan-900/30 border-cyan-500 text-gray-900',
      iconColor: 'text-gray-900',
    },
    {
      id: 'note_quote',
      icon: 'PhoneIcon',
      title: 'Ofertă Gratuită',
      description: 'Sună-ne sau completează formularul pentru o evaluare exactă și ofertă personalizată.',
      color: 'bg-green-900/30 border-green-400 text-gray-900',
      iconColor: 'text-gray-900',
    },
  ];

  const addOns = [
    {
      id: 'addon_headlight',
      service: 'Restaurare Faruri',
      price: '1000 MDL',
      description: 'Per set (ambele faruri)',
    },
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-800 to-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Notes */}
        <div className="max-w-4xl mx-auto mb-16">
          <h2 className="text-3xl font-bold text-gray-100 mb-8 text-center">
            Informații Importante
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            {notes.map((note) => (
              <div
                key={note.id}
                className={`${note.color} border-2 rounded-2xl p-6 animate-fade-up`}
              >
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <Icon name={note.icon as any} size={28} className={note.iconColor} />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg mb-2 text-white">{note.title}</h3>
                    <p className="text-sm opacity-90 text-white">{note.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Add-ons */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-100 mb-8 text-center">
            Servicii Adiționale
          </h2>
          <div className="bg-gray-800 border border-gray-700 rounded-2xl shadow-md overflow-hidden">
            <div className="divide-y divide-gray-700">
              {addOns.map((addon, index) => (
                <div
                  key={addon.id}
                  className={`p-6 hover:bg-gray-700 transition-colors animate-fade-up delay-${index * 100}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-100 mb-1">{addon.service}</h3>
                      <p className="text-sm text-gray-300">{addon.description}</p>
                    </div>
                    <div className="text-right ml-4">
                      <p className="text-2xl font-bold text-primary">{addon.price}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}