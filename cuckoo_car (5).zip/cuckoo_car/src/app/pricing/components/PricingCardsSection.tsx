import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export default function PricingCardsSection() {
  const pricingPlans = [
    {
      id: 'pricing_cars',
      icon: 'TruckIcon',
      title: 'Autoturisme',
      price: '2500-4000',
      currency: 'MDL',
      description: 'Pentru mașini personale',
      features: [
        'Curățare chimică interioară completă',
        'Aspirare profesională',
        'Curățare scaune textile',
        'Tratare piele (dacă e cazul)',
        'Curățare bord și console',
        'Eliminare mirosuri',
        'Durată: 3-5 ore',
      ],
      popular: true,
    },
    {
      id: 'pricing_minibus',
      icon: 'TruckIcon',
      title: 'Microbuze',
      price: '2500-4500',
      currency: 'MDL',
      description: '2-6 locuri',
      features: [
        'Toate serviciile pentru autoturisme',
        'Suprafață mai mare',
        'Mai multe scaune',
        'Atenție la detalii',
        'Curățare pardoseală extinsă',
        'Eliminare mirosuri puternice',
        'Durată: 4-6 ore',
      ],
      popular: false,
    },
    {
      id: 'pricing_trucks',
      icon: 'TruckIcon',
      title: 'Camioane',
      price: '5000-6000',
      currency: 'MDL',
      description: 'Cabine profesionale',
      features: [
        'Curățare cabină completă',
        'Spații de dormit (dacă există)',
        'Curățare tapițerie specială',
        'Eliminare mirosuri persistente',
        'Curățare compartimente',
        'Atenție la zonele grele',
        'Durată: 6-12 ore',
      ],
      popular: false,
    },
    {
      id: 'pricing_agricultural',
      icon: 'WrenchScrewdriverIcon',
      title: 'Utilaje Agricole',
      price: 'La cerere',
      currency: '',
      description: 'Tractoare, combine',
      features: [
        'Evaluare individuală',
        'Curățare cabină',
        'Îndepărtare praf și noroi',
        'Curățare zone dificile',
        'Preț în funcție de stare',
        'Serviciu specializat',
        'Contactează-ne pentru ofertă',
      ],
      popular: false,
    },
  ];

  const delayClasses = ['delay-0', 'delay-100', 'delay-200', 'delay-300'];

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {pricingPlans.map((plan, index) => (
            <div
              key={plan.id}
              className={`relative bg-gray-800 rounded-2xl p-6 border-2 transition-all duration-300 hover:shadow-xl animate-fade-up ${delayClasses[index]} ${
                plan.popular
                  ? 'border-primary shadow-lg'
                  : 'border-gray-700 hover:border-primary/50'
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 bg-primary text-gray-900 text-xs font-bold rounded-full">
                  CEL MAI POPULAR
                </div>
              )}

              {/* Icon */}
              <div className="w-14 h-14 bg-primary/20 rounded-xl flex items-center justify-center mb-4">
                <Icon name={plan.icon as any} size={28} className="text-primary" />
              </div>

              {/* Title & Description */}
              <h3 className="text-xl font-bold text-gray-100 mb-1">{plan.title}</h3>
              <p className="text-sm text-gray-300 mb-4">{plan.description}</p>

              {/* Price */}
              <div className="mb-6">
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold text-gray-100">{plan.price}</span>
                  {plan.currency && <span className="text-lg text-gray-300">{plan.currency}</span>}
                </div>
              </div>

              {/* Features */}
              <ul className="space-y-3 mb-6">
                {plan.features.map((feature, idx) => (
                  <li key={`${plan.id}_feature_${idx}`} className="flex items-start gap-2 text-sm">
                    <Icon name="CheckCircleIcon" size={18} className="text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-gray-300">{feature}</span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <Link
                href="/online-booking"
                className={`block w-full py-3 text-center font-semibold rounded-xl transition-all ${
                  plan.popular
                    ? 'bg-primary text-black hover:bg-primary/90' :'bg-gray-700 text-gray-100 border border-gray-600 hover:border-primary hover:text-primary'
                }`}
              >
                Rezervă Acum
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}