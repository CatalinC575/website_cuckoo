import type { Metadata } from 'next';
import Header from '@/components/common/Header';
import Footer from '@/components/common/Footer';
import PricingCardsSection from './components/PricingCardsSection';
import PricingNotesSection from './components/PricingNotesSection';
import Link from 'next/link';
import Icon from '@/components/ui/AppIcon';

export const metadata: Metadata = {
  title: 'Prețuri - Cuckoo Car',
  description: 'Prețuri transparente pentru curățare chimică interioară auto. De la 3000 MDL pentru autoturisme. Servicii în toată Moldova.',
  keywords: 'prețuri curățare auto, tarife auto detailing, Moldova',
};

export default function PricingPage() {
  return (
    <>
      <Header />
      <main className="min-h-screen pt-20">
        {/* Page Header */}
        <section className="py-16 bg-gradient-to-br from-gray-800 to-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center animate-fade-up">
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-100 mb-4">
              Prețuri Transparente
            </h1>
            <p className="text-lg text-gray-300 max-w-2xl mx-auto">
              Fără costuri ascunse. Prețuri clare în funcție de tipul vehiculului.
            </p>
          </div>
        </section>

        <PricingCardsSection />
        <PricingNotesSection />

        {/* CTA Section */}
        <section className="py-16 bg-gray-900">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="max-w-3xl mx-auto">
              <h2 className="text-3xl font-bold text-gray-100 mb-4">
                Ai Întrebări Despre Prețuri?
              </h2>
              <p className="text-lg text-gray-300 mb-8">
                Contactează-ne pentru o ofertă personalizată sau rezervă direct online
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="/online-booking"
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary text-gray-900 font-bold rounded-xl hover:bg-primary/90 transition-all hover:shadow-lg"
                >
                  <Icon name="CalendarIcon" size={24} />
                  <span>Rezervă Acum</span>
                </Link>
                <Link
                  href="/contact"
                  className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-gray-800 text-gray-100 font-semibold rounded-xl border-2 border-gray-700 hover:border-primary hover:text-primary transition-all"
                >
                  <Icon name="PhoneIcon" size={24} />
                  <span>Contactează-ne</span>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}