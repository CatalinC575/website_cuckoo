"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

export default function AdminLoginPage() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // Check if already logged in
    if (typeof window !== 'undefined') {
      const isLoggedIn = localStorage.getItem('adminLoggedIn');
      if (isLoggedIn === 'true') {
        router.push('/admin/dashboard');
      }
    }
  }, [router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    // Simple password check (in production, use proper authentication)
    if (password === 'admin123') {
      localStorage.setItem('adminLoggedIn', 'true');
      router.push('/admin/dashboard');
    } else {
      setError('Parolă incorectă');
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center px-4">
      <div className="max-w-md w-full">
        <div className="bg-gray-800 border border-gray-700 rounded-2xl p-8 shadow-xl">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-primary rounded-xl flex items-center justify-center mx-auto mb-4">
              <Icon name="ShieldCheckIcon" size={32} className="text-gray-900" />
            </div>
            <h1 className="text-3xl font-bold text-gray-100 mb-2">Admin Panel</h1>
            <p className="text-gray-400">Autentificare necesară</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label htmlFor="password" className="block text-sm font-semibold text-gray-100 mb-2">
                Parolă
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
                placeholder="Introdu parola"
              />
            </div>

            {error && (
              <div className="bg-red-900/30 border border-red-500 rounded-xl p-3 flex items-center gap-2">
                <Icon name="ExclamationTriangleIcon" size={20} className="text-red-400" />
                <p className="text-sm text-red-400">{error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-primary text-black font-bold rounded-xl hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <Icon name="ArrowPathIcon" size={20} className="animate-spin" />
                  <span>Se încarcă...</span>
                </>
              ) : (
                <>
                  <Icon name="LockOpenIcon" size={20} />
                  <span>Autentificare</span>
                </>
              )}
            </button>
          </form>

          <p className="text-xs text-center text-gray-500 mt-6">
            Parolă implicită: admin123
          </p>
        </div>
      </div>
    </div>
  );
}
