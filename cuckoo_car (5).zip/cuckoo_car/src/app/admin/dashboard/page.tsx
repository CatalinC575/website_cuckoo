"use client";

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Icon from '@/components/ui/AppIcon';

interface Booking {
  id: string;
  fullName: string;
  phone: string;
  email: string;
  city: string;
  vehicleType: string;
  vehicleBrand: string;
  preferredDate: string;
  preferredTime: string;
  service: string;
  notes: string;
  timestamp: string;
  status: string;
}

export default function AdminDashboardPage() {
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filteredBookings, setFilteredBookings] = useState<Booking[]>([]);
  const [filterType, setFilterType] = useState<'all' | 'day' | 'month' | 'year'>('all');
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedMonth, setSelectedMonth] = useState('');
  const [selectedYear, setSelectedYear] = useState('');
  const router = useRouter();

  useEffect(() => {
    // Check authentication
    if (typeof window !== 'undefined') {
      const isLoggedIn = localStorage.getItem('adminLoggedIn');
      if (isLoggedIn !== 'true') {
        router.push('/admin/login');
        return;
      }

      // Load bookings
      const storedBookings = JSON.parse(localStorage.getItem('bookings') || '[]');
      setBookings(storedBookings);
      setFilteredBookings(storedBookings);
    }
  }, [router]);

  useEffect(() => {
    applyFilters();
  }, [filterType, selectedDate, selectedMonth, selectedYear, bookings]);

  const applyFilters = () => {
    let filtered = [...bookings];

    if (filterType === 'day' && selectedDate) {
      filtered = filtered.filter(b => b.preferredDate === selectedDate);
    } else if (filterType === 'month' && selectedMonth) {
      filtered = filtered.filter(b => b.preferredDate.startsWith(selectedMonth));
    } else if (filterType === 'year' && selectedYear) {
      filtered = filtered.filter(b => b.preferredDate.startsWith(selectedYear));
    }

    setFilteredBookings(filtered);
  };

  const handleStatusChange = (bookingId: string, newStatus: string) => {
    const updatedBookings = bookings.map(booking => 
      booking.id === bookingId ? { ...booking, status: newStatus } : booking
    );
    
    setBookings(updatedBookings);
    localStorage.setItem('bookings', JSON.stringify(updatedBookings));
  };

  const handleLogout = () => {
    localStorage.removeItem('adminLoggedIn');
    router.push('/admin/login');
  };

  const getServiceLabel = (service: string) => {
    const labels: Record<string, string> = {
      interior: 'Curățare Chimică Interioară',
      faruri: 'Restaurare Faruri',
      complet: 'Pachet Complet',
    };
    return labels[service] || service;
  };

  const getVehicleTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      autoturism: 'Autoturism',
      microbuz: 'Microbuz',
      camion: 'Camion',
      utilaj: 'Utilaj Agricol',
    };
    return labels[type] || type;
  };

  return (
    <div className="min-h-screen bg-gray-900 py-8 px-4">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 mb-6 flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-100 mb-2">Admin Dashboard</h1>
            <p className="text-gray-400">Gestionează rezervările online</p>
          </div>
          <button
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white font-semibold rounded-xl hover:bg-red-700 transition-all"
          >
            <Icon name="ArrowRightOnRectangleIcon" size={20} />
            <span>Deconectare</span>
          </button>
        </div>

        {/* Filters */}
        <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-100 mb-4 flex items-center gap-2">
            <Icon name="FunnelIcon" size={24} className="text-primary" />
            Filtrează Rezervările
          </h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-100 mb-2">Tip Filtru</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value as any)}
                className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary"
              >
                <option value="all">Toate</option>
                <option value="day">Pe Zi</option>
                <option value="month">Pe Lună</option>
                <option value="year">Pe An</option>
              </select>
            </div>

            {filterType === 'day' && (
              <div>
                <label className="block text-sm font-semibold text-gray-100 mb-2">Selectează Ziua</label>
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => setSelectedDate(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary"
                />
              </div>
            )}

            {filterType === 'month' && (
              <div>
                <label className="block text-sm font-semibold text-gray-100 mb-2">Selectează Luna</label>
                <input
                  type="month"
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(e.target.value)}
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary"
                />
              </div>
            )}

            {filterType === 'year' && (
              <div>
                <label className="block text-sm font-semibold text-gray-100 mb-2">Selectează Anul</label>
                <input
                  type="number"
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(e.target.value)}
                  placeholder="2026"
                  className="w-full px-4 py-3 bg-gray-900 border border-gray-700 text-gray-100 rounded-xl focus:ring-2 focus:ring-primary"
                />
              </div>
            )}
          </div>
        </div>

        {/* Stats */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
          <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">Total Rezervări</p>
                <p className="text-3xl font-bold text-gray-100">{bookings.length}</p>
              </div>
              <div className="w-12 h-12 bg-primary/20 rounded-xl flex items-center justify-center">
                <Icon name="CalendarIcon" size={24} className="text-primary" />
              </div>
            </div>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">Filtrate</p>
                <p className="text-3xl font-bold text-gray-100">{filteredBookings.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-500/20 rounded-xl flex items-center justify-center">
                <Icon name="FunnelIcon" size={24} className="text-blue-400" />
              </div>
            </div>
          </div>

          <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400 mb-1">Neconfirmate</p>
                <p className="text-3xl font-bold text-gray-100">
                  {filteredBookings.filter(b => b.status === 'neconfirmat').length}
                </p>
              </div>
              <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center">
                <Icon name="ExclamationTriangleIcon" size={24} className="text-yellow-400" />
              </div>
            </div>
          </div>
        </div>

        {/* Bookings List */}
        <div className="bg-gray-800 border border-gray-700 rounded-2xl p-6">
          <h2 className="text-xl font-bold text-gray-100 mb-4 flex items-center gap-2">
            <Icon name="ClipboardDocumentListIcon" size={24} className="text-primary" />
            Lista Rezervări ({filteredBookings.length})
          </h2>

          {filteredBookings.length === 0 ? (
            <div className="text-center py-12">
              <Icon name="InboxIcon" size={48} className="text-gray-600 mx-auto mb-4" />
              <p className="text-gray-400">Nu există rezervări pentru acest filtru</p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredBookings.map((booking) => (
                <div
                  key={booking.id}
                  className="bg-gray-900 border border-gray-700 rounded-xl p-6 hover:border-primary transition-colors"
                >
                  <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {/* Client Info */}
                    <div>
                      <h3 className="text-sm font-semibold text-gray-400 mb-2">Informații Client</h3>
                      <p className="text-gray-100 font-bold mb-1">{booking.fullName}</p>
                      <p className="text-sm text-gray-300 mb-1">📞 {booking.phone}</p>
                      <p className="text-sm text-gray-300 mb-1">📧 {booking.email}</p>
                      <p className="text-sm text-gray-300">🏙️ {booking.city}</p>
                    </div>

                    {/* Vehicle Info */}
                    <div>
                      <h3 className="text-sm font-semibold text-gray-400 mb-2">Informații Vehicul</h3>
                      <p className="text-gray-100 font-bold mb-1">{booking.vehicleBrand}</p>
                      <p className="text-sm text-gray-300 mb-1">🚙 {getVehicleTypeLabel(booking.vehicleType)}</p>
                      <p className="text-sm text-gray-300">✨ {getServiceLabel(booking.service)}</p>
                    </div>

                    {/* Booking Details */}
                    <div>
                      <h3 className="text-sm font-semibold text-gray-400 mb-2">Detalii Rezervare</h3>
                      <p className="text-gray-100 font-bold mb-1">📅 {booking.preferredDate}</p>
                      <p className="text-sm text-gray-300 mb-1">⏰ {booking.preferredTime}</p>
                      <p className="text-sm text-gray-300 mb-2">
                        🕒 {new Date(booking.timestamp).toLocaleString('ro-RO')}
                      </p>
                      <div className="flex items-center gap-2">
                        <select
                          value={booking.status || 'neconfirmat'}
                          onChange={(e) => handleStatusChange(booking.id, e.target.value)}
                          className={`px-3 py-1 text-xs font-semibold rounded-full border-2 focus:outline-none focus:ring-2 focus:ring-primary transition-all ${
                            (booking.status || 'neconfirmat') === 'neconfirmat'
                              ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' : (booking.status ||'neconfirmat') === 'confirmat'
                              ? 'bg-blue-500/20 text-blue-400 border-blue-500/30' :'bg-green-500/20 text-green-400 border-green-500/30'
                          }`}
                        >
                          <option value="neconfirmat">⚠️ NECONFIRMAT</option>
                          <option value="confirmat">✓ CONFIRMAT</option>
                          <option value="finalizat">✓✓ FINALIZAT</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {booking.notes && (
                    <div className="mt-4 pt-4 border-t border-gray-700">
                      <h3 className="text-sm font-semibold text-gray-400 mb-1">Note Adiționale</h3>
                      <p className="text-sm text-gray-300">{booking.notes}</p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
